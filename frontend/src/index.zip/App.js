import './App.css';
import './styles.css';
import { BrowserRouter as Router, Route, Switch, Link, BrowserRouter, Routes } from 'react-router-dom';
import './webroute/Home';
import './webroute/Ticket';
import Home from './webroute/Home';
import Ticket from './webroute/Ticket';
import TicketQueue from './webroute/TicketQueue';
import { Routes as ReactRoutes, Route as ReactRoute} from 'react-router-dom';

function App() {
  return (
    <div className='App'>
      <ReactRoutes>
        <ReactRoute path='/' element={<Home/>}/>
        <ReactRoute path='/Ticket' element={<Ticket/>}/>
        <ReactRoute path='/TicketQueue' element={<TicketQueue/>} />
      </ReactRoutes>
    </div>
  );
}
export default App;
